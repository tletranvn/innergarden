<?php

namespace Knp\Component\Pager\Exception;

class InvalidValueException extends \UnexpectedValueException
{
}
