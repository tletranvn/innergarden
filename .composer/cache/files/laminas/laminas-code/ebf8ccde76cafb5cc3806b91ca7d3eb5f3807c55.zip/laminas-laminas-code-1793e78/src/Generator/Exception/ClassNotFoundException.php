<?php

namespace Laminas\Code\Generator\Exception;

class ClassNotFoundException extends RuntimeException implements
    ExceptionInterface
{
}
