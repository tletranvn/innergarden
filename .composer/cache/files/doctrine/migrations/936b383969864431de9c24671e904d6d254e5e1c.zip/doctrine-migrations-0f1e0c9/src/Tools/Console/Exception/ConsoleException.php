<?php

declare(strict_types=1);

namespace Doctrine\Migrations\Tools\Console\Exception;

use Doctrine\Migrations\Exception\MigrationException;

interface ConsoleException extends MigrationException
{
}
