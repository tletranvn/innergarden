<?php

declare(strict_types=1);

namespace Doctrine\Bundle\MongoDBBundle\Tests\DependencyInjection\Fixtures\Bundles\RepositoryServiceBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class RepositoryServiceBundle extends Bundle
{
}
