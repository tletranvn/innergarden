<?php

declare(strict_types=1);

namespace Doctrine\Bundle\MongoDBBundle\Tests\DependencyInjection\Fixtures\Bundles\OtherXmlBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OtherXmlBundle extends Bundle
{
}
