<?php

declare(strict_types=1);

namespace Doctrine\Bundle\MongoDBBundle\Tests\Fixtures\CommandBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CommandBundle extends Bundle
{
}
