<?php

declare(strict_types=1);

namespace Doctrine\Bundle\MongoDBBundle\Tests\DependencyInjection\Fixtures\Bundles\XmlBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class XmlBundle extends Bundle
{
}
