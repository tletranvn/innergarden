<?php

declare(strict_types=1);

namespace Doctrine\Bundle\MongoDBBundle\Tests\DependencyInjection\Fixtures\Bundles\NewXmlBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class NewXmlBundle extends Bundle
{
}
