<?php

declare(strict_types=1);

namespace Doctrine\Bundle\MongoDBBundle\Tests\DependencyInjection\Fixtures\Bundles\DocumentListenerBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DocumentListenerBundle extends Bundle
{
}
