<?php

namespace Doctrine\DBAL\Exception;

class DatabaseDoesNotExist extends DatabaseObjectNotFoundException
{
}
