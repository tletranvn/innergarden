<?php

namespace Doctrine\DBAL\Exception;

class TransactionRolledBack extends DriverException
{
}
