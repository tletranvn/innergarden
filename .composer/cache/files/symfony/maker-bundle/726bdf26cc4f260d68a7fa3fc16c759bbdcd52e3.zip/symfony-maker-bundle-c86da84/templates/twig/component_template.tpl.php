<div{{ attributes }}>
    <!-- component HTML -->
</div>
