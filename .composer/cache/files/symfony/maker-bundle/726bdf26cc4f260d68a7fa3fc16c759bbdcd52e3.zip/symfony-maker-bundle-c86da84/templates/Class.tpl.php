<?= "<?php\n" ?>

namespace <?= $namespace; ?>;

class <?= $class_name."\n" ?>
{
}
