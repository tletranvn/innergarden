<?= "<?php\n" ?>

namespace <?= $namespace; ?>;

use Symfony\UX\TwigComponent\Attribute\AsTwigComponent;

#[AsTwigComponent]
final class <?= $class_name."\n" ?>
{
}
