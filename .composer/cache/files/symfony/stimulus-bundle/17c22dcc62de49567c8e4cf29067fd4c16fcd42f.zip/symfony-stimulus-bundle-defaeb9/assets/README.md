# @symfony/stimulus-bundle

JavaScript assets of the [symfony/stimulus-bundle](https://packagist.org/packages/symfony/stimulus-bundle) PHP package.

## Installation

Due to compatibility issues with JSDelivr causing the package not to work as expected, the package is not yet released on NPM.
Read more at [symfony/ux#2708](https://github.com/symfony/ux/issues/2708).

## Resources

-   [Documentation](https://symfony.com/bundles/StimulusBundle/current/index.html)
-   [Report issues](https://github.com/symfony/ux/issues) and
    [send Pull Requests](https://github.com/symfony/ux/pulls)
    in the [main Symfony UX repository](https://github.com/symfony/ux)
