<?php

return [
    'Names' => [
        'TOP' => [
            'T$',
            'Tongan Paʻanga',
        ],
    ],
];
