<?php

return [
    'Names' => [
        'NZD' => [
            '$',
            'New Zealand Dollar',
        ],
    ],
];
