<?php

return [
    'Names' => [
        'AWG' => [
            'Afl.',
            'Arubaanse gulden',
        ],
    ],
];
