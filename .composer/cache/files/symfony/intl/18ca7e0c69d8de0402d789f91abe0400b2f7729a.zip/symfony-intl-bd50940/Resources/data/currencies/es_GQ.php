<?php

return [
    'Names' => [
        'XAF' => [
            'FCFA',
            'franco CFA de África Central',
        ],
    ],
];
