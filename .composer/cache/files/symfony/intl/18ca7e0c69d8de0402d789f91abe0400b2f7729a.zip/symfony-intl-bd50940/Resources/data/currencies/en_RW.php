<?php

return [
    'Names' => [
        'RWF' => [
            'RF',
            'Rwandan Franc',
        ],
    ],
];
