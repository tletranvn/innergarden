<?php

return [
    'Names' => [
        'BMD' => [
            '$',
            'Bermudian Dollar',
        ],
    ],
];
