<?php

return [
    'Names' => [
        'CNY' => [
            'CN¥',
            '人民币',
        ],
        'MOP' => [
            'MOP$',
            '澳门币',
        ],
    ],
];
