<?php

return [
    'Names' => [
        'RWF' => [
            'RF',
            'RWF',
        ],
    ],
];
