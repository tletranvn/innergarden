<?php

return [
    'Names' => [
        'MOP' => [
            'MOP$',
            'pataca macaense',
        ],
    ],
];
