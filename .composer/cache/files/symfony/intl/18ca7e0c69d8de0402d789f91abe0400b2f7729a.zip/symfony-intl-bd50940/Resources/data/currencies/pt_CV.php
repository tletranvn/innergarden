<?php

return [
    'Names' => [
        'CVE' => [
            '​',
            'escudo cabo-verdiano',
        ],
        'PTE' => [
            'PTE',
            'escudo português',
        ],
    ],
];
