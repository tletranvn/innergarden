<?php

return [
    'Names' => [
        'EUR' => [
            '€',
            'Euro',
        ],
    ],
];
